---
name: tooluniverse-drug-regulatory
description: Drug regulatory and approval research — FDA substance registry, ATC/EPC classification, EMA decisions, generic-drug status, FDA Orange Book exclusivity, NDA/BLA pathways. Use for jurisdiction-aware approval status (FDA vs EMA), generic vs brand availability, exclusivity expiry tracking, and regulatory pathway selection. Always specifies the market when reporting status.
triggers:
  - keywords: [FDA, Orange Book, generic drug, UNII, RxClass, ATC code, drug class, NDA, ANDA, patent, exclusivity, DailyMed, drug label, adverse reactions, regulatory, approval]
  - patterns: ["FDA approved", "generic available", "patent expiration", "drug class", "ATC code", "Orange Book", "DailyMed", "drug labeling", "UNII"]
disable-model-invocation: true
---

# Drug Regulatory Research

**Regulatory status depends on jurisdiction.** FDA approval does not equal EMA approval — check the specific market the user is asking about. Generic availability depends on BOTH patent expiry AND regulatory approval — a patent may have expired but no ANDA may yet be filed or approved. Exclusivity codes (NCE, ODE, PED) can block generics even after patent expiry; always check `FDA_OrangeBook_get_exclusivity` before concluding a generic can enter. A 505(b)(2) NDA is not a generic — it requires its own clinical data and gets its own exclusivity period.

**LOOK UP DON'T GUESS**: never assume NDA numbers, exclusivity dates, or ATC codes — always call FDAGSRS, Orange Book, and RxClass tools to retrieve current data; regulatory status changes with new approvals and expirations.

Regulatory intelligence for drugs: identify FDA substances, classify drugs by therapeutic
category, check approval and generic status, retrieve label sections, and find clinical trials.

## When to Use

- "What is the FDA regulatory status of semaglutide?"
- "Is there a generic for Humira?"
- "What ATC class does metformin belong to?"
- "Get adverse reactions from the ibuprofen drug label"
- "When does the patent for Eliquis expire?"
- "List all drugs in the ACE inhibitor class"
- "Find clinical trials for a biosimilar of adalimumab"

## NOT for (use other skills instead)

- Drug-drug interactions -> Use `tooluniverse-drug-drug-interaction`
- Pharmacogenomics / dosing by genotype -> Use `tooluniverse-pharmacogenomics`
- Drug mechanism of action / target binding -> Use `tooluniverse-drug-mechanism-research`
- Drug repurposing / new indications -> Use `tooluniverse-drug-repurposing`

---

## Workflow Overview

```
Input (drug name / brand name / UNII)
  |
  v
Phase 1: Substance Identification  -- FDAGSRS_search_substances, FDAGSRS_get_substance
  |
  v
Phase 2: Drug Classification       -- RxClass_get_drug_classes, RxClass_find_classes
  |
  v
Phase 3: Approval & Generic Status -- FDA_OrangeBook_search_drug, FDA_OrangeBook_check_generic_availability
  |
  v
Phase 4: Patent & Exclusivity      -- FDA_OrangeBook_get_patent_info, FDA_OrangeBook_get_exclusivity
  |
  v
Phase 5: Label Parsing             -- DailyMed_parse_adverse_reactions, DailyMed_parse_dosing, etc.
  |
  v
Phase 6: Clinical Trials           -- search_clinical_trials
  |
  v
Phase 7: Pharmacovigilance         -- FAERS_count_reactions_by_drug_event (param: medicinalproduct)
  |
  v
Phase 8: Literature & Approval     -- PubMed_search_articles, OpenFDA_get_approval_history, RxNorm_get_drug_names
```

> **Supplementary tools** (not in core phases but useful):
> - `OpenFDA_get_approval_history` — full FDA submission/approval history (requires `operation` param)
> - `FAERS_count_reactions_by_drug_event` — top adverse events by report count (param: `medicinalproduct`, ALL CAPS)
> - `RxNorm_get_drug_names` — resolve drug to RXCUI and brand names
> - `drugbank_vocab_search` — DrugBank ID, CAS, UNII lookup
> - `PubMed_search_articles` — regulatory and clinical literature

---

## Phase 1: Substance Identification (FDAGSRS)

**FDAGSRS_search_substances**: `query` (string REQUIRED -- drug name, UNII, InChIKey, or formula), `substance_class` (string, optional: "chemical"/"protein"/"nucleic acid"/"polymer"/"mixture"), `limit` (int, 1-50, default 10).
Returns `{status, data: [{uuid, unii, name, substanceClass, status, formula, smiles, synonyms, xrefs}], metadata: {query, total, returned, substance_class_filter}}` (`data` is a list).
- `xrefs` (dict) holds the substance's cross-references (DrugBank IDs, ATC codes, CAS numbers ...).
- Use to get the official UNII identifier before calling `FDAGSRS_get_substance`.

**FDAGSRS_get_substance**: `unii` (string REQUIRED, 10-char FDA UNII code).
Returns complete substance record including all synonyms, names, structure, and cross-references.
- Provides definitive list of all registered names (INN, USAN, brand, chemical).

**FDAGSRS_get_structure**: `unii` (string REQUIRED).
Returns `{status, data: {smiles, formula, inchikey, molfile, molecular_weight, stereochemistry, optical_activity}}`.
- Only works for chemical substances; returns error for biologics, mixtures, polymers.

```python
# Full substance lookup workflow
search = tu.tools.FDAGSRS_search_substances(query="semaglutide")
unii = search["data"][0]["unii"]
full = tu.tools.FDAGSRS_get_substance(unii=unii)
```

---

## Phase 2: Drug Classification (RxClass)

**RxClass_get_drug_classes**: `drug_name` (string, drug name), `rxcui` (string, RxNorm RXCUI -- alternative to drug_name), `rela_source` (string, optional: "ATC"/"FDASPL"/"MESH"/"VA"), `limit` (int, default 20).
Returns `{status, data: [{classId, className, classType, rxcui, drugName, tty, rela, relaSource}], metadata}` (`data` is a list).
- Returns ALL classification systems unless `rela_source` filters to one.
- `class_type` values: "ATC1-4", "EPC" (FDA Established Pharmacologic Class), "MoA", "VA", "MESH".
- Use to find a drug's ATC code, pharmacological class, mechanism of action label.

**RxClass_find_classes**: `query` (string REQUIRED, keyword e.g., "beta blocker"), `class_type` (string, optional: "ATC1-4"/"EPC"/"MoA"), `limit` (int, default 20).
Returns `{status, data: [{classId, className, classType}]}` (a list; `classType` shows the system: ATC1-4, EPC, MOA, DISPOS ...).
- Use when you need to find a class ID before calling `RxClass_get_class_members`.

**RxClass_get_class_members**: `class_id` (string REQUIRED, e.g., "M01AE"), `rela_source` (string, optional: "ATC"/"FDASPL"), `ttys` (string, optional: "IN" for ingredients), `limit` (int, default 50).
Returns `{status, data: [{rxcui, name, tty}]}`.
- `rela_source` must match the class system: the default `ATC` only lists members of ATC codes (e.g. `A02BC`). For EPC/MoA class IDs such as `N0000175525` pass `rela_source="DAILYMED"` (or `"FDASPL"`); with the default it returns an empty list.
- `ttys="IN"` restricts to active ingredient-level entries (recommended).

```python
# Find all proton pump inhibitors
classes = tu.tools.RxClass_find_classes(query="proton pump inhibitor", class_type="EPC")
class_id = classes["data"][0]["classId"]  # N0000175525 (EPC class)
members = tu.tools.RxClass_get_class_members(class_id=class_id, rela_source="DAILYMED", ttys="IN")
```

---

## Phase 3: Approval & Generic Status (FDA Orange Book / Purple Book)

**Orange Book covers small-molecule drugs; biologics and biosimilars (e.g. "is there a biosimilar of adalimumab") are a different FDA list entirely** — use `FDAPurpleBook_search_products` for those instead of Orange Book, which won't have them.

**FDA_OrangeBook_search_drug**: `brand_name` (string), `generic_name` (string), `application_number` (string), `limit` (int, default 10).
Returns `{status, data: {products: [{brand_name, generic_name, dosage_form, strength, te_code, application_number, approval_date}]}}`.
- Use brand name (UPPERCASE) or generic name to find NDA/ANDA numbers and approval info.
- `te_code`: Therapeutic Equivalence code (e.g., "AB" = therapeutically equivalent).

**FDA_OrangeBook_check_generic_availability**: `brand_name` (string), `generic_name` (string).
Returns `{status, data: {reference_listed_drug, generics_available: bool, generics_count, generic_products: [...]}}`.
- Primary tool for "is there a generic?" questions.

**FDA_OrangeBook_get_te_code**: No special params beyond `brand_name`/`application_number`.
Returns therapeutic equivalence codes for substitutability assessment.

**FDA_OrangeBook_get_approval_history**: `application_number` (string, e.g., "NDA020402").
Returns chronological approval history including supplemental approvals and label changes.

```python
# Check generic availability
result = tu.tools.FDA_OrangeBook_check_generic_availability(brand_name="LIPITOR")
# result["data"]["generics_available"] -> True
# result["data"]["generics_count"] -> N
```

---

## Phase 4: Patent & Exclusivity

**FDA_OrangeBook_get_patent_info**: `application_number` (string), `brand_name` (string).
Returns patent information. Note: Full patent numbers and expiration dates require Orange Book data files.

**FDA_OrangeBook_get_exclusivity**: `application_number` (string), `brand_name` (string).
Returns `{status, data: {exclusivities: [{exclusivity_code, exclusivity_date, description}]}}`.
- `exclusivity_code` values: "NCE" (New Chemical Entity, 5 years), "ODE" (Orphan Drug, 7 years), "PED" (Pediatric, 6 months), "NP" (New Product), "M" (new formulation).

---

## Phase 5: Label Parsing (DailyMed)

All DailyMed parse tools accept either `setid` (SPL Set ID UUID) OR `drug_name` (auto-lookup).
Using `drug_name` is recommended when the setid is unknown.

**DailyMed_parse_adverse_reactions**: `setid` or `drug_name`. Returns structured adverse reaction table with frequencies and severity.

**DailyMed_parse_dosing**: `setid` or `drug_name`. Returns dosage and administration section (doses, schedules, renal/hepatic adjustments).

**DailyMed_parse_contraindications**: `setid` or `drug_name`. Returns contraindications section.

**DailyMed_parse_drug_interactions**: `setid` or `drug_name`. Returns drug-drug interaction section with clinical management guidance.

**DailyMed_parse_clinical_pharmacology**: `setid` or `drug_name`. Returns PK/PD data (Cmax, AUC, half-life, protein binding, metabolism pathway).

**DailyMed_search_spls**: `drug_name` (string), returns SPL Set IDs for that drug. Use to find `setid` when needed explicitly.

```python
# Parse adverse reactions for apixaban
ae = tu.tools.DailyMed_parse_adverse_reactions(drug_name="apixaban")
```

---

## Phase 6: Clinical Trials

**search_clinical_trials**: `condition` (string), `intervention` (string), `query_term` (string), `pageSize` (int, alias: `max_results`/`limit`), `overall_status` (array, alias: `status`).
Returns `{status, data: {studies: [{NCT ID, brief_title, brief_summary, overall_status, phase}], total_count}}`.
- Use `intervention` for drug name, `condition` for disease.
- Filter `overall_status=["RECRUITING"]` for active enrollment.
- `total_count` may be None even when results exist; check `len(studies) > 0`.

```python
# Find recruiting trials for a biosimilar
trials = tu.tools.search_clinical_trials(
    intervention="adalimumab biosimilar",
    overall_status=["RECRUITING"],
    pageSize=10
)
```

---

## Example Workflows

### Workflow 1: Full Regulatory Profile for a Drug

```
1. FDAGSRS_search_substances(query="apixaban")
   -> UNII, substance class, ATC/DrugBank cross-refs

2. RxClass_get_drug_classes(drug_name="apixaban", rela_source="ATC")
   -> ATC code B01AF02 (direct factor Xa inhibitor)

3. FDA_OrangeBook_search_drug(brand_name="ELIQUIS")
   -> NDA206518, approval date, TE code

4. FDA_OrangeBook_check_generic_availability(brand_name="ELIQUIS")
   -> Generic availability status

5. FDA_OrangeBook_get_exclusivity(brand_name="ELIQUIS")
   -> Exclusivity codes and expiration dates

6. DailyMed_parse_adverse_reactions(drug_name="apixaban")
   -> Bleeding rates and other AEs from label
```

### Workflow 2: List All Drugs in a Therapeutic Class

```
1. RxClass_find_classes(query="ACE inhibitor", class_type="EPC")
   -> class_id for "Angiotensin-Converting Enzyme Inhibitor"

2. RxClass_get_class_members(class_id=<id>, ttys="IN")
   -> All ACE inhibitors (enalapril, lisinopril, ramipril, etc.)

3. For each drug: RxClass_get_drug_classes(drug_name=drug)
   -> Confirm ATC code and additional classifications
```

### Workflow 3: Drug Label Review

```
1. DailyMed_parse_adverse_reactions(drug_name="metformin")
   -> AE frequencies (GI: lactic acidosis, nausea, diarrhea)

2. DailyMed_parse_contraindications(drug_name="metformin")
   -> eGFR thresholds, renal impairment contraindications

3. DailyMed_parse_drug_interactions(drug_name="metformin")
   -> Iodinated contrast, carbonic anhydrase inhibitor interactions

4. DailyMed_parse_clinical_pharmacology(drug_name="metformin")
   -> Half-life, renal clearance, bioavailability
```

---

## Common Mistakes

- Orange Book `brand_name` must be UPPERCASE (e.g., `"LIPITOR"`)
- `FDAGSRS_get_substance` requires UNII, not drug name — call `FDAGSRS_search_substances` first
- `FDAGSRS_get_structure` only works for chemical substances, not biologics
- `RxClass_get_class_members`: pass `ttys="IN"` to restrict to active ingredients
- `search_clinical_trials` `overall_status` must be an array: `["RECRUITING"]`

---

## Reasoning Framework

### Interpretation Guidance

**Approval pathways**: A 505(b)(1) NDA is a full new drug application with complete safety/efficacy data from the sponsor. A 505(b)(2) NDA relies partly on published literature or FDA findings for an already-approved drug (common for reformulations, new routes). An ANDA (Abbreviated NDA) is the generic pathway requiring only bioequivalence to the reference listed drug.

**Orange Book patent and exclusivity**: NCE (New Chemical Entity) exclusivity gives 5 years of data protection. ODE (Orphan Drug Exclusivity) gives 7 years. PED (Pediatric) adds 6 months to existing patents/exclusivity. A TE code of "AB" means the generic is therapeutically equivalent and substitutable. No TE code or "BX" means substitutability is not established.

**DailyMed label sections**: The "Adverse Reactions" section distinguishes clinical trial rates (controlled) from post-marketing reports (uncontrolled, signal-only). "Contraindications" are absolute; "Warnings and Precautions" are conditional risks. "Clinical Pharmacology" provides PK parameters (Cmax, AUC, half-life) essential for drug interaction and dosing assessment.

### Synthesis Questions

A complete drug regulatory report should answer:
1. What is the current FDA approval status and pathway (NDA vs ANDA vs 505(b)(2))?
2. Are generic equivalents available, and what is their therapeutic equivalence rating?
3. When do key patents and exclusivities expire (or have they already)?
4. What drug class does this belong to (ATC, EPC, MoA), and what are peer drugs in the class?
5. What are the most clinically significant adverse reactions and contraindications from the label?

