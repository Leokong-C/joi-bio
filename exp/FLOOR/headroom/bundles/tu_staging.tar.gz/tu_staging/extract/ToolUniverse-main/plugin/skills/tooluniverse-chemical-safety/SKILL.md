---
name: tooluniverse-chemical-safety
description: Chemical safety and toxicology assessment integrating ADMET-AI predictions, CTD toxicogenomics, PubChemTox experimental data, GHS/IARC hazard classification, and exposure-context analysis. Use for chemical hazard identification, occupational/consumer-product toxicity, dose-response evaluation, and acute (LD50) vs chronic toxicity assessment. Distinguishes drug toxicity from environmental chemical toxicity.
disable-model-invocation: true
---

# Chemical Safety & Toxicology Assessment

**Toxicity assessment**: identify the chemical, check known hazards (GHS, IARC), then look for ADMET predictions. Dose makes the poison — always consider exposure level, as a compound that is toxic at high doses may be safe at relevant exposures. Distinguish between acute toxicity (LD50, GHS category) and chronic hazards (carcinogenicity, endocrine disruption) — they require different risk management approaches. Computational predictions (ADMETAI) are T3 evidence and must be anchored by experimental data from PubChemTox or FDA labels wherever available. When evidence conflicts between prediction and experiment, always defer to the experimental finding.

**LOOK UP DON'T GUESS**: never assume GHS categories, IARC classification, or CTD disease links — always call PubChemTox and CTD tools to retrieve current classifications before reporting.

Comprehensive chemical safety analysis integrating predictive AI models, curated toxicogenomics databases, regulatory safety data, and chemical-biological interaction networks.

## When to Use This Skill

**Triggers**:
- "Is this chemical toxic?" / "Assess the safety profile of [drug/chemical]"
- "What are the ADMET properties of [SMILES]?"
- "What genes does [chemical] interact with?" / "What diseases are linked to [chemical] exposure?"
- "Drug safety assessment" / "Environmental health risk" / "Chemical hazard profiling"

**Use Cases**:
1. **Predictive Toxicology**: AI-predicted endpoints (AMES, DILI, LD50, carcinogenicity, hERG) via SMILES
2. **ADMET Profiling**: Absorption, distribution, metabolism, excretion, toxicity
3. **Toxicogenomics**: Chemical-gene-disease mapping from CTD
4. **Regulatory Safety**: FDA label warnings, contraindications, adverse reactions
5. **Drug Safety**: DrugBank safety + FDA labels combined
6. **Chemical-Protein Interactions**: STITCH-based interaction networks
7. **Environmental Toxicology**: Chemical-disease associations for contaminants

---

## COMPUTE, DON'T DESCRIBE
When analysis requires computation (statistics, data processing, scoring, enrichment), write and run Python code via Bash. Don't describe what you would do — execute it and report actual results. Use ToolUniverse tools to retrieve data, then Python (pandas, scipy, statsmodels, matplotlib) to analyze it.

## KEY PRINCIPLES

1. **Report-first approach** - Create report file FIRST, then populate progressively
2. **Tool parameter verification** - Verify params via `get_tool_info` before calling unfamiliar tools
3. **Evidence grading** - Grade all safety claims by evidence strength (T1-T4)
4. **Citation requirements** - Every toxicity finding must have inline source attribution
5. **Mandatory completeness** - All sections must exist with data or explicit "No data" notes
6. **Disambiguation first** - Resolve compound identity (name -> SMILES, CID, ChEMBL ID) before analysis
7. **Negative results documented** - "No toxicity signals found" is data; empty sections are failures
8. **Conservative risk assessment** - When evidence is ambiguous, flag as "requires further investigation"
9. **English-first queries** - Always use English chemical/drug names in tool calls

---

## Evidence Grading System (MANDATORY)

| Tier | Symbol | Criteria | Examples |
|------|--------|----------|----------|
| **T1** | [T1] | Direct human evidence, regulatory finding | FDA boxed warning, clinical trial toxicity |
| **T2** | [T2] | Animal studies, validated in vitro | Nonclinical toxicology, AMES positive, animal LD50 |
| **T3** | [T3] | Computational prediction, association data | ADMET-AI prediction, CTD association |
| **T4** | [T4] | Database annotation, text-mined | Literature mention, unvalidated database entry |

Evidence grades MUST appear in: Executive Summary, Toxicity Predictions, Regulatory Safety, Chemical-Gene Interactions, Risk Assessment.

---

## Core Strategy: 8 Research Phases

```
Chemical/Drug Query
|
+-- PHASE 0: Compound Disambiguation (ALWAYS FIRST)
|   Resolve name -> SMILES, PubChem CID, ChEMBL ID, formula, weight
|
+-- PHASE 1: Predictive Toxicology (ADMET-AI)
|   AMES, DILI, ClinTox, carcinogenicity, LD50, hERG, skin reaction
|   Stress response pathways, nuclear receptor activity
|
+-- PHASE 2: ADMET Properties
|   BBB penetrance, bioavailability, clearance, CYP interactions, physicochemical
|
+-- PHASE 3: Toxicogenomics (CTD)
|   Chemical-gene interactions, chemical-disease associations
|
+-- PHASE 4: Regulatory Safety (FDA Labels)
|   Boxed warnings, contraindications, adverse reactions, nonclinical tox
|
+-- PHASE 5: Drug Safety Profile (DrugBank)
|   Toxicity data, contraindications, drug interactions
|
+-- PHASE 6: Chemical-Protein Interactions (STITCH)
|   Direct binding, off-target effects, interaction confidence
|
+-- PHASE 7: Structural Alerts (ChEMBL)
|   PAINS, Brenk, Glaxo structural alerts
|
+-- SYNTHESIS: Integrated Risk Assessment
    Risk classification, evidence summary, data gaps, recommendations
```

See **phase-procedures-detailed.md** for complete tool parameters, decision logic, output templates, and fallback strategies for each phase.

---

## Tool Summary by Phase

### Phase 0: Compound Disambiguation
- `PubChem_get_CID_by_compound_name` (`name`: str)
- `PubChem_get_compound_properties_by_CID` (`cid`: int)
- `ChEMBL_get_molecule` (if ChEMBL ID available)

### Phase 1: Predictive Toxicology
> **Dependency**: ADMET-AI tools require `pip install tooluniverse[ml]`. If unavailable, skip to Phase 3 and use CTD + PubChemTox as alternatives.

- `ADMETAI_predict_toxicity` (`smiles`: list[str]) - AMES, DILI, ClinTox, LD50, hERG, etc.
- `ADMETAI_predict_stress_response` (`smiles`: list[str])
- `ADMETAI_predict_nuclear_receptor_activity` (`smiles`: list[str])

### Phase 2: ADMET Properties
- `ADMETAI_predict_BBB_penetrance` / `_bioavailability` / `_clearance_distribution` / `_CYP_interactions` / `_physicochemical_properties` / `_solubility_lipophilicity_hydration` (all take `smiles`: list[str])

### Phase 3: Toxicogenomics
- `CTD_get_chemical_gene_interactions` (`input_terms`: str) — chemical name, returns gene interactions across species
- `CTD_get_chemical_diseases` (`input_terms`: str) — chemical-disease associations with evidence type

### Phase 3.5: PubChem Toxicity Data
- `PubChemTox_get_toxicity_values` (`cid`: int) — LD50, LC50, NOAEL reference values
- `PubChemTox_get_ghs_classification` (`cid`: int) — GHS hazard classification and pictograms
- `PubChemTox_get_carcinogen_classification` (`cid`: int) — NTP/IARC carcinogenicity assessments
- `PubChemTox_get_acute_effects` (`cid`: int) — acute toxicity by route/species
- `PubChemTox_get_toxicity_summary` (`cid`: int) — integrated toxicity overview

### Phase 3.6: Adverse Outcome Pathways
- `AOPWiki_list_aops` (`keyword`: str) — search for relevant AOPs by chemical/mechanism
- `AOPWiki_get_aop` (`aop_id`: int) — full AOP detail: MIE, key events, adverse outcome

### Phase 3.7: Environmental Exposure Context (US facilities)
> Use for exposure/environmental-justice screening — locate regulated facilities near a community before assessing population-level exposure.
- `EPA_search_tri_facilities` (`state`, `city`, `limit`) — Toxics Release Inventory facilities reporting toxic chemical releases
- `EPA_search_frs_facilities` (`state`, `city`, `limit`) — Facility Registry Service (all EPA-regulated facilities) for broader siting/permitting context

### Phase 4: Regulatory Safety (for pharmaceuticals only)
> **Environmental chemicals**: Skip Phases 4-5 (no FDA labels/DrugBank). Use CTD + PubChemTox + AOPWiki instead.

- `FDA_get_boxed_warning_info_by_drug_name` / `_contraindications_` / `_adverse_reactions_` / `_warnings_` (all take `drug_name`: str)

### Phase 5: Drug Safety (for pharmaceuticals only)
- `drugbank_get_safety_by_drug_name_or_drugbank_id` (`query`, `case_sensitive`, `exact_match`, `limit` - all 4 required)

### Phase 6: Chemical-Protein Interactions
- `STITCH_get_chemical_protein_interactions` (`identifiers`: list[str], `species`: int)
- **Fallback** (if STITCH fails for industrial chemicals): `STRING_get_interaction_partners` for key target genes (e.g., ESR1 for endocrine disruptors)
- `DGIdb_get_drug_gene_interactions` (`genes`: list[str]) — for target druggability context

### Phase 7: Structural Alerts
- `ChEMBL_search_compound_structural_alerts` (`molecule_chembl_id`: str)
- `DrugProps_pains_filter` (`smiles`: str) — direct RDKit FilterCatalog screen for PAINS/Brenk/NIH-alert substructures from a SMILES string; use this when there's no ChEMBL ID yet (novel/investigational compounds), since it needs only a SMILES. Live-verified response: `{"is_clean": bool, "pains": {"pass": bool, "matches": [...], "count": int}}` (plus Brenk/NIH sub-objects) — a compound can be `is_clean: false` while `pains.pass: true` if the hit came from a different filter, so check each sub-filter's own `pass` field rather than only the top-level flag.
- `DrugProps_lipinski_filter` (`smiles`: str) — Rule-of-Five plus Veber/Pfizer-3-75/Egan/Ghose drug-likeness filters in one call (MW, cLogP, HBD, HBA, TPSA, rotatable bonds, Csp3 fraction, pass/fail per rule set). Add to Phase 0/2 as a quick oral-druglikeness screen alongside ADMET-AI.
- `DrugProps_calculate_qed` (`smiles`: str) — Quantitative Estimate of Drug-likeness (Bickerton et al. 2012), a single 0-1 score integrating 8 descriptors; live-verified categories include `"Medium (borderline)"` and `"High"` — useful as one summary number when comparing multiple candidate structures rather than reading 8 separate descriptors per compound.

---

## Risk Classification Matrix

| Risk Level | Criteria |
|-----------|----------|
| **CRITICAL** | FDA boxed warning OR multiple [T1] toxicity findings OR active DILI + active hERG |
| **HIGH** | FDA warnings OR [T2] animal toxicity OR multiple active ADMET endpoints |
| **MEDIUM** | Some [T3] predictions positive OR CTD disease associations OR structural alerts |
| **LOW** | All ADMET endpoints negative AND no FDA/DrugBank flags AND no CTD concerns |
| **INSUFFICIENT DATA** | Fewer than 3 phases returned data |

---

## Report Structure

```
# Chemical Safety & Toxicology Report: [Compound Name]
**Generated**: YYYY-MM-DD | **SMILES**: [...] | **CID**: [...]

## Executive Summary (risk classification + key findings, all graded)
## 1. Compound Identity (disambiguation table)
## 2. Predictive Toxicology (ADMET-AI endpoints)
## 3. ADMET Profile (absorption, distribution, metabolism, excretion)
## 4. Toxicogenomics (CTD chemical-gene-disease)
## 5. Regulatory Safety (FDA label data)
## 6. Drug Safety Profile (DrugBank)
## 7. Chemical-Protein Interactions (STITCH network)
## 8. Structural Alerts (ChEMBL)
## 9. Integrated Risk Assessment (classification, evidence summary, gaps, recommendations)
## Appendix: Methods and Data Sources
```

See **report-templates.md** for full section templates with example tables.

---

## Mandatory Completeness Checklist

- [ ] Phase 0: Compound disambiguated (SMILES + CID minimum)
- [ ] Phase 1: At least 5 toxicity endpoints or "prediction unavailable"
- [ ] Phase 2: ADMET A/D/M/E sections or "not available"
- [ ] Phase 3: CTD queried; results or "no data in CTD"
- [ ] Phase 4: FDA labels queried; results or "not FDA-approved"
- [ ] Phase 5: DrugBank queried; results or "not found"
- [ ] Phase 6: STITCH queried; results or "no data available"
- [ ] Phase 7: Structural alerts checked or "ChEMBL ID not available"
- [ ] Synthesis: Risk classification with evidence summary
- [ ] Evidence Grading: All findings have [T1]-[T4] annotations
- [ ] Data Gaps: Explicitly listed

---

## Common Use Patterns

1. **Novel Compound**: SMILES -> Phase 0 (resolve) -> Phase 1 (toxicity) -> Phase 2 (ADMET) -> Phase 7 (structural alerts) -> Synthesis
2. **Approved Drug Review**: Drug name -> All phases (0-7) -> Complete safety dossier
3. **Environmental Chemical**: Chemical name -> Phase 0 -> Phase 1-2 -> Phase 3 (CTD, key) -> Phase 6 (STITCH) -> Synthesis
4. **Batch Screening**: Multiple SMILES -> Phase 0 -> Phase 1-2 (batch) -> Comparative table -> Synthesis
5. **Toxicogenomic Deep-Dive**: Chemical + gene/disease interest -> Phase 0 -> Phase 3 (expanded CTD) -> Literature -> Synthesis

---

## Limitations

- **ADMET-AI**: Computational [T3]; should not replace experimental testing
- **CTD**: May lag behind latest literature by 6-12 months
- **FDA**: Only covers FDA-approved drugs; not applicable to environmental chemicals
- **DrugBank**: Primarily drugs; limited industrial chemical coverage
- **STITCH**: Lower score thresholds increase false positives
- **ChEMBL**: Structural alerts require ChEMBL ID; not all compounds have one
- **Novel compounds**: May only have ADMET-AI predictions (no database evidence)
- **SMILES validity**: Invalid SMILES cause ADMET-AI failures

---

## Reference Files

- **phase-procedures-detailed.md** - Complete tool parameters, decision logic, output templates, fallback strategies per phase
- **evidence-grading.md** - Evidence grading details and examples
- **report-templates.md** - Full report section templates with example tables
- **phase-details.md** - Additional phase context
- **test_skill.py** - Test suite

---

## Summary

**Total tools integrated**: 25+ tools across 6 databases (ADMET-AI, CTD, FDA, DrugBank, STITCH, ChEMBL)

**Best for**: Drug safety assessment, chemical hazard profiling, environmental toxicology, ADMET characterization, toxicogenomic analysis

**Outputs**: Structured markdown report with risk classification (Critical/High/Medium/Low), evidence grading [T1-T4], and actionable recommendations
