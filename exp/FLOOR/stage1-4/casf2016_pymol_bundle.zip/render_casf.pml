# AutoDock Vina 1.2.7 re-docking vs crystal pose — CASF-2016 core set
# PyMOL: File > Run Script, or in the PyMOL prompt:  @render_casf.pml
reinitialize
bg_color white
set ray_opaque_background, 1
set antialias, 2
set ray_shadows, 0
set cartoon_transparency, 0.55
set surface_quality, 1

# ---- success: 1s38 / MAQ  RMSD(top-1) = 0.10 A  logKa = 5.15  Vina = -7.89 kcal/mol
load 1s38_receptor.pdb, 1s38_rec
load 1s38_crystal.sdf, 1s38_crystal
load 1s38_vina_top1.sdf, 1s38_vina
hide everything, 1s38_rec
show cartoon, 1s38_rec and polymer
color grey80, 1s38_rec
show sticks, 1s38_crystal
color grey30, 1s38_crystal and elem C
show sticks, 1s38_vina
color marine, 1s38_vina and elem C
util.cnc('1s38_crystal or 1s38_vina')
set stick_radius, 0.14, 1s38_crystal
set stick_radius, 0.14, 1s38_vina
show sticks, byres (1s38_rec within 4.5 of 1s38_crystal) and sidechain
color palecyan, byres (1s38_rec within 4.5 of 1s38_crystal) and sidechain and elem C
orient 1s38_crystal
zoom visible, 3
png 1s38_success_RMSD0.10.png, width=2000, height=1500, dpi=300, ray=1
disable 1s38_rec
disable 1s38_crystal
disable 1s38_vina

# ---- borderline: 5c2h / 4XU  RMSD(top-1) = 2.01 A  logKa = 11.09  Vina = -9.91 kcal/mol
load 5c2h_receptor.pdb, 5c2h_rec
load 5c2h_crystal.sdf, 5c2h_crystal
load 5c2h_vina_top1.sdf, 5c2h_vina
hide everything, 5c2h_rec
show cartoon, 5c2h_rec and polymer
color grey80, 5c2h_rec
show sticks, 5c2h_crystal
color grey30, 5c2h_crystal and elem C
show sticks, 5c2h_vina
color marine, 5c2h_vina and elem C
util.cnc('5c2h_crystal or 5c2h_vina')
set stick_radius, 0.14, 5c2h_crystal
set stick_radius, 0.14, 5c2h_vina
show sticks, byres (5c2h_rec within 4.5 of 5c2h_crystal) and sidechain
color palecyan, byres (5c2h_rec within 4.5 of 5c2h_crystal) and sidechain and elem C
orient 5c2h_crystal
zoom visible, 3
png 5c2h_borderline_RMSD2.01.png, width=2000, height=1500, dpi=300, ray=1
disable 5c2h_rec
disable 5c2h_crystal
disable 5c2h_vina

# ---- failure: 3k5v / STI  RMSD(top-1) = 11.92 A  logKa = 6.3  Vina = -10.98 kcal/mol
load 3k5v_receptor.pdb, 3k5v_rec
load 3k5v_crystal.sdf, 3k5v_crystal
load 3k5v_vina_top1.sdf, 3k5v_vina
hide everything, 3k5v_rec
show cartoon, 3k5v_rec and polymer
color grey80, 3k5v_rec
show sticks, 3k5v_crystal
color grey30, 3k5v_crystal and elem C
show sticks, 3k5v_vina
color marine, 3k5v_vina and elem C
util.cnc('3k5v_crystal or 3k5v_vina')
set stick_radius, 0.14, 3k5v_crystal
set stick_radius, 0.14, 3k5v_vina
show sticks, byres (3k5v_rec within 4.5 of 3k5v_crystal) and sidechain
color palecyan, byres (3k5v_rec within 4.5 of 3k5v_crystal) and sidechain and elem C
orient 3k5v_crystal
zoom visible, 3
png 3k5v_failure_RMSD11.92.png, width=2000, height=1500, dpi=300, ray=1
disable 3k5v_rec
disable 3k5v_crystal
disable 3k5v_vina

# grey sticks = crystal pose, blue sticks = Vina top-1 pose, pale cyan = pocket side chains